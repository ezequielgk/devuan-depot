var searchData=
[
  ['034_20–_20malformed_20number_20literal_0',['XKB-034 – Malformed number literal',['../error-index.html#XKB-034',1,'']]],
  ['043_20–_20conflicting_20key_20type_20preserve_20entries_1',['XKB-043 – Conflicting key type preserve entries',['../error-index.html#XKB-043',1,'']]],
  ['052_20–_20integer_20overflow_2',['XKB-052 – Integer overflow',['../error-index.html#XKB-052',1,'']]],
  ['060_20–_20unsupported_20modifier_20mask_3',['XKB-060 – Unsupported modifier mask',['../error-index.html#XKB-060',1,'']]],
  ['077_20–_20expected_20array_20entry_4',['XKB-077 – Expected array entry',['../error-index.html#XKB-077',1,'']]],
  ['082_20–_20invalid_20numeric_20keysym_5',['XKB-082 – Invalid numeric keysym',['../error-index.html#XKB-082',1,'']]]
];
