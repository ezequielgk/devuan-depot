var searchData=
[
  ['800_20–_20conflicting_20modmap_0',['800 – conflicting modmap',['../error-index.html#XKB-800',1,'XKB-800 – Conflicting modmap'],['../todo.html#_todo000021',1,'XKB-800 – Conflicting modmap']]],
  ['812_20–_20unknown_20field_1',['XKB-812 – Unknown field',['../error-index.html#XKB-812',1,'']]],
  ['822_20–_20keymap_20compilation_20failed_2',['XKB-822 – Keymap compilation failed',['../error-index.html#XKB-822',1,'']]],
  ['844_20–_20unknown_20action_20type_3',['XKB-844 – Unknown action type',['../error-index.html#XKB-844',1,'']]],
  ['883_20–_20conflicting_20key_20action_4',['XKB-883 – Conflicting key action',['../error-index.html#XKB-883',1,'']]],
  ['893_20–_20conflicting_20key_20type_20merging_20groups_5',['XKB-893 – Conflicting key type merging groups',['../error-index.html#XKB-893',1,'']]]
];
