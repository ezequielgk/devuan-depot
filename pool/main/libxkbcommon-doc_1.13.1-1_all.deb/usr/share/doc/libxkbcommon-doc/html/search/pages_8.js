var searchData=
[
  ['keyboard_20layouts_0',['Packaging keyboard layouts',['../packaging-keyboard-layouts.html',1,'']]],
  ['keymap_20text_20format_20v1_20and_20v2_1',['The XKB keymap text format, V1 and V2',['../keymap-text-format-v1-v2.html',1,'']]],
  ['keysym_20transformations_2',['Keysym Transformations',['../group__keysyms.html',1,'']]]
];
