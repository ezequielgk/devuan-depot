var searchData=
[
  ['layouts_0',['Packaging keyboard layouts',['../packaging-keyboard-layouts.html',1,'']]],
  ['libxkbcommon_1',['libxkbcommon',['../index.html',1,'']]],
  ['license_2',['License',['../detailed-license.html',1,'']]],
  ['list_3',['list',['../deprecated.html',1,'Deprecated List'],['../todo.html',1,'Todo List']]],
  ['locale_4',['Compose Locale',['../group__compose.html',1,'']]]
];
