var searchData=
[
  ['name_0',['name',['../error-index.html#XKB-302',1,'XKB-302 – Deprecated keysym name'],['../error-index.html#XKB-305',1,'XKB-305 – Non base group name'],['../error-index.html#XKB-523',1,'XKB-523 – Conflicting key name']]],
  ['name_20index_1',['XKB-903 – Missing symbols group name index',['../error-index.html#XKB-903',1,'']]],
  ['name_20statements_2',['name statements',['../todo.html#_todo000008',1,'LED name statements'],['../keymap-text-format-v1-v2.html#indicator-name',1,'LED name statements'],['../keymap-text-format-v1-v2.html#name-statements',1,'Name statements']]],
  ['names_3',['names',['../group__led-names.html',1,'LEDs names'],['../group__legacy-virtual-modifier-names.html',1,'Legacy virtual modifier names'],['../group__real-modifier-names.html',1,'Real modifiers names'],['../user-configuration.html#user-config-system-file-names',1,'Using system file names'],['../group__virtual-modifier-names.html',1,'Virtual modifiers names'],['../error-index.html#XKB-239',1,'XKB-239 – Conflicting key type level names']]],
  ['names_20for_20common_20modifiers_20and_20leds_4',['Predefined names for common modifiers and LEDs',['../group__modifier-names.html',1,'']]],
  ['no_20valid_20default_20include_20path_5',['XKB-632 – No valid default include path',['../error-index.html#XKB-632',1,'']]],
  ['non_20base_20group_20name_6',['XKB-305 – Non base group name',['../error-index.html#XKB-305',1,'']]],
  ['non_20canonical_20modifiers_7',['Canonical and non-canonical modifiers',['../keymap-text-format-v1-v2.html#canonical-and-non-canonical-modifiers',1,'']]],
  ['not_20found_8',['XKB-338 – Included file not found',['../error-index.html#XKB-338',1,'']]],
  ['not_20work_9',['Why does my key combination to switch between layouts not work?',['../faq.html#why-does-my-key-combination-to-switch-between-layouts-not-work',1,'']]],
  ['not_20work_20as_20expected_10',['Why does my keyboard layout not work as expected?',['../faq.html#why-does-my-keyboard-layout-not-work-as-expected',1,'']]],
  ['not_20work_20properly_11',['Why do my keyboard shortcuts not work properly?',['../faq.html#why-do-my-keyboard-shortcuts-not-work-properly',1,'']]],
  ['notes_12',['Release notes',['../release-notes.html',1,'']]],
  ['number_20literal_13',['XKB-034 – Malformed number literal',['../error-index.html#XKB-034',1,'']]],
  ['numeric_20keysym_14',['numeric keysym',['../error-index.html#XKB-082',1,'XKB-082 – Invalid numeric keysym'],['../error-index.html#XKB-489',1,'XKB-489 – Numeric keysym']]],
  ['numeric_20modifier_20masks_15',['Avoid using numeric modifier masks',['../keymap-text-format-v1-v2.html#avoid-using-numeric-modifier-masks',1,'']]]
];
