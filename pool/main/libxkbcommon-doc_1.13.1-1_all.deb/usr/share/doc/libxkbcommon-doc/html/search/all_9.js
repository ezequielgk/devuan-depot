var searchData=
[
  ['9_0',['libxkbcommon ≤ 1.9',['../faq.html#libxkbcommon--19',1,'']]],
  ['901_20–_20conflicting_20key_20symbols_20entry_1',['XKB-901 – Conflicting key symbols entry',['../error-index.html#XKB-901',1,'']]],
  ['903_20–_20missing_20symbols_20group_20name_20index_2',['XKB-903 – Missing symbols group name index',['../error-index.html#XKB-903',1,'']]],
  ['935_20–_20conflicting_20key_20fields_3',['XKB-935 – Conflicting key fields',['../error-index.html#XKB-935',1,'']]],
  ['949_20–_20invalid_20identifier_4',['XKB-949 – Invalid identifier',['../error-index.html#XKB-949',1,'']]],
  ['965_20–_20unresolved_20keymap_20symbol_5',['XKB-965 – Unresolved keymap symbol',['../error-index.html#XKB-965',1,'']]],
  ['967_20–_20invalid_20rules_20syntax_6',['XKB-967 – Invalid rules syntax',['../error-index.html#XKB-967',1,'']]],
  ['971_20–_20undeclared_20modifiers_20in_20key_20type_7',['XKB-971 – Undeclared modifiers in key type',['../error-index.html#XKB-971',1,'']]]
];
