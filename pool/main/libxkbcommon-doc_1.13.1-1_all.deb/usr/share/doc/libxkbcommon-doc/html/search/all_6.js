var searchData=
[
  ['607_20–_20invalid_20unicode_20escape_20sequence_0',['XKB-607 – Invalid unicode escape sequence',['../error-index.html#XKB-607',1,'']]],
  ['623_20–_20invalid_20real_20modifier_1',['XKB-623 – Invalid real modifier',['../error-index.html#XKB-623',1,'']]],
  ['632_20–_20no_20valid_20default_20include_20path_2',['XKB-632 – No valid default include path',['../error-index.html#XKB-632',1,'']]],
  ['639_20–_20unknown_20default_20field_3',['XKB-639 – Unknown default field',['../error-index.html#XKB-639',1,'']]],
  ['645_20–_20unknown_20char_20escape_20sequence_4',['XKB-645 – Unknown char escape sequence',['../error-index.html#XKB-645',1,'']]],
  ['661_20–_20invalid_20included_20file_5',['XKB-661 – Invalid included file',['../error-index.html#XKB-661',1,'']]],
  ['679_20–_20invalid_20compose_20locale_6',['XKB-679 – Invalid compose locale',['../error-index.html#XKB-679',1,'']]],
  ['685_20–_20invalid_20compose_20syntax_7',['XKB-685 – Invalid compose syntax',['../error-index.html#XKB-685',1,'']]],
  ['693_20–_20incompatible_20actions_20and_20keysyms_20count_8',['XKB-693 – Incompatible actions and keysyms count',['../error-index.html#XKB-693',1,'']]]
];
