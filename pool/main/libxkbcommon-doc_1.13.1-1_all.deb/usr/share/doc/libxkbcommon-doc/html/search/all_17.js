var searchData=
[
  ['of_20the_20file_0',['Format of the file',['../rule-file-format.html#format-of-the-file',1,'']]],
  ['once_1',['XKB-700 – Multiple groups at once',['../error-index.html#XKB-700',1,'']]],
  ['operation_2',['XKB-478 – Invalid operation',['../error-index.html#XKB-478',1,'']]],
  ['operator_3',['XKB-345 – Unknown operator',['../error-index.html#XKB-345',1,'']]],
  ['option_4',['Adding an option',['../user-configuration.html#user-config-option',1,'']]],
  ['option_20and_20symbols_5',['Example: layout, option and symbols',['../rule-file-format.html#rules-options-example',1,'']]],
  ['options_6',['options',['../rule-file-format.html#rules-layout-specific-options-example',1,'Example: layout-specific options'],['../structxkb__rule__names.html#a556899eafb333c440be64ede408644df',1,'xkb_rule_names::options']]],
  ['or_20lock_7',['How do I break a latch before triggering another latch or lock?',['../faq.html#how-do-i-break-a-latch-before-triggering-another-latch-or-lock',1,'']]],
  ['or_20propose_20a_20patch_8',['Where are the standard keyboard layouts designed?&lt;br/&gt;How to report an issue or propose a patch?',['../faq.html#where-are-the-standard-keyboard-layouts-designedbrhow-to-report-an-issue-or-propose-a-patch',1,'']]],
  ['overflow_9',['XKB-052 – Integer overflow',['../error-index.html#XKB-052',1,'']]],
  ['overriding_20the_20system_20sections_10',['Overriding the system sections',['../user-configuration.html#overriding-the-system-sections',1,'']]],
  ['overview_11',['overview',['../group__compose.html',1,'Overview'],['../group__x11.html',1,'Overview']]]
];
