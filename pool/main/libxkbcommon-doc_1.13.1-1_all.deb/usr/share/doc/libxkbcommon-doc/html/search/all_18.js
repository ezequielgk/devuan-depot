var searchData=
[
  ['packagers_0',['Instructions for keyboard layout packagers',['../packaging-keyboard-layouts.html#instructions-for-keyboard-layout-packagers',1,'']]],
  ['packaging_20keyboard_20layouts_1',['Packaging keyboard layouts',['../packaging-keyboard-layouts.html',1,'']]],
  ['patch_2',['Where are the standard keyboard layouts designed?&lt;br/&gt;How to report an issue or propose a patch?',['../faq.html#where-are-the-standard-keyboard-layouts-designedbrhow-to-report-an-issue-or-propose-a-patch',1,'']]],
  ['path_3',['path',['../error-index.html#XKB-161',1,'XKB-161 – Invalid path'],['../error-index.html#XKB-632',1,'XKB-632 – No valid default include path']]],
  ['path_20list_4',['Example: include path list',['../keymap-text-format-v1-v2.html#example-include-path-list',1,'']]],
  ['paths_5',['Include Paths',['../group__include-path.html',1,'']]],
  ['per_20key_6',['How do I define multiple groups per key?',['../faq.html#how-do-i-define-multiple-groups-per-key',1,'']]],
  ['percent_20expansion_7',['XKB-762 – Rules invalid layout index percent expansion',['../error-index.html#XKB-762',1,'']]],
  ['pointer_20actions_8',['pointer actions',['../keymap-text-format-v1-v2.html#pointer-actions',1,'Pointer actions'],['../todo.html#_todo000010',1,'Pointer actions'],['../todo.html#_todo000011',1,'Pointer actions'],['../todo.html#_todo000012',1,'Pointer actions'],['../todo.html#_todo000013',1,'Pointer actions']]],
  ['portability_9',['Modifiers portability',['../keymap-text-format-v1-v2.html#modifiers-portability',1,'']]],
  ['predefined_20names_20for_20common_20modifiers_20and_20leds_10',['Predefined names for common modifiers and LEDs',['../group__modifier-names.html',1,'']]],
  ['preserve_20entries_11',['XKB-043 – Conflicting key type preserve entries',['../error-index.html#XKB-043',1,'']]],
  ['preserve_20result_12',['XKB-195 – Illegal key type preserve result',['../error-index.html#XKB-195',1,'']]],
  ['private_20action_13',['Private action',['../keymap-text-format-v1-v2.html#private-action',1,'']]],
  ['process_14',['process',['../rule-file-format.html#process',1,'Process'],['../rule-file-format.html#rmlvo-resolution',1,'RMLVO resolution process']]],
  ['processing_15',['Processing',['../keymap-text-format-v1-v2.html#processing',1,'']]],
  ['properly_16',['Why do my keyboard shortcuts not work properly?',['../faq.html#why-do-my-keyboard-shortcuts-not-work-properly',1,'']]],
  ['propose_20a_20patch_17',['Where are the standard keyboard layouts designed?&lt;br/&gt;How to report an issue or propose a patch?',['../faq.html#where-are-the-standard-keyboard-layouts-designedbrhow-to-report-an-issue-or-propose-a-patch',1,'']]],
  ['protocol_18',['XKB the protocol',['../xkb-intro.html#xkb-the-protocol',1,'']]]
];
