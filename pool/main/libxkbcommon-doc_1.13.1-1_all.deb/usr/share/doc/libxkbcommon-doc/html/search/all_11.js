var searchData=
[
  ['handling_0',['Logging Handling',['../group__logging.html',1,'']]],
  ['how_20do_20i_20break_20a_20latch_20before_20triggering_20another_20latch_20or_20lock_1',['How do I break a latch before triggering another latch or lock?',['../faq.html#how-do-i-break-a-latch-before-triggering-another-latch-or-lock',1,'']]],
  ['how_20do_20i_20customize_20my_20layout_2',['How do I customize my layout?',['../faq.html#how-do-i-customize-my-layout',1,'']]],
  ['how_20do_20i_20define_20multiple_20groups_20per_20key_3',['How do I define multiple groups per key?',['../faq.html#how-do-i-define-multiple-groups-per-key',1,'']]],
  ['how_20do_20i_20swap_20some_20keys_4',['How do I swap some keys?',['../faq.html#how-do-i-swap-some-keys',1,'']]],
  ['how_20do_20i_20test_20my_20custom_20layout_20without_20installing_20it_5',['How do I test my custom layout without installing it?',['../faq.html#how-do-i-test-my-custom-layout-without-installing-it',1,'']]],
  ['how_20key_20types_20work_6',['How key types work',['../keymap-text-format-v1-v2.html#how-key-types-work',1,'']]],
  ['how_20to_20get_20the_20keys_20that_20trigger_20modifiers_7',['How to get the keys that trigger modifiers?',['../faq.html#how-to-get-the-keys-that-trigger-modifiers',1,'']]],
  ['how_20to_20get_20the_20virtual_20modifier_20encoding_8',['How to get the virtual modifier encoding?',['../faq.html#how-to-get-the-virtual-modifier-encoding',1,'']]],
  ['how_20to_20report_20an_20issue_20or_20propose_20a_20patch_9',['Where are the standard keyboard layouts designed?&lt;br/&gt;How to report an issue or propose a patch?',['../faq.html#where-are-the-standard-keyboard-layouts-designedbrhow-to-report-an-issue-or-propose-a-patch',1,'']]]
];
